<?php

namespace Magium\ActiveDirectory;

class InvalidRequestException extends \Exception
{

}
