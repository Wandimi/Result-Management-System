<?php

namespace Magium\ActiveDirectory;

class ClientException extends \Exception
{

}
