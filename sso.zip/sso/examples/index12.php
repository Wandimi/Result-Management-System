<?php 
	    require_once "functions.php";

	    if(confirmLogin()){
	    	   $salt = $_SESSION['id']; 

	    	   $name = ucwords(user($salt, 'name'));
	    	   $course = ucwords(user($salt, 'course'));
	    	   $username = ucwords(user($salt, 'username')); 
	    	   $gender = user($salt, 'username');
	    	   $profile1 = user($salt,'profile');
	    	   $course = user($salt,'course');
	    	   $Adm = user($salt,'Adm');
	    	   $phone_no = user($salt,'phone_no');
	    	   $email = user($salt,'email');
	    	   $studyyear = user($salt,'studyyear');
                
	    	    if($profile1 == "" && $gender =="Male"){
    				$profilImage1 = "male.jpg";
    			} else if($profile1 == "" && $gender =="Female") {
    				$profilImage1 = "female.jpg";
    			} else {
    				$profilImage1 = $profile1; 
    			}
    			
	    	?> 
<!DOCTYPE html> 
<html>
<head>
<link rel="shortcut icon" href="https://e-learning.piu.ac.ke/wp-content/uploads/2020/05/cropped-PIU-ICON-512x512-2-1-192x192.png" />
	<title>RESULTS CONFIRMATION</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" type="text/css" href="main.css" />
	<link rel="stylesheet" type="text/css" href="style.css" />
	<!-- include our jQuery file --> 
	<script src="jquery.js"></script> 
	
	<script src="chat.js"></script> 
	<script>
	    //custom scroll bars for some dive elements this
	    // script is optional 
		
	</script> 
</head>
<body style="position: relative;">
	<div class="overlay"></div> 
	<div class="overlay-data">
		<h2>Please Wait ....</h2>
	</div> 

	<div class="container content-holder">
		<div class="page-header">
			<div class="pull-left" style="margin-left: 50px;"></div> 
		</div>
		<div class='net' style="background: #2e1353; padding: 10px; color: white; text-align: center; font-size: 18px; display: none;">
		      We are having trouble connecting to the server. Please wait while we reconnect you 
		      <div class="pull-right"><img src="small-loading.gif" /></div> 
		</div> 
		<div class="page-header show-simples" style="opacity:0.8; display: none; font-size: 20px; padding: 10px; text-align: center; background:url(ic_next.png) left center no-repeat green; color: white;">
			     <span>Nothing to show right now</span>
		</div> 

			<!-- end of the chat toolBar -->

			<div class="row">
				<br>
				</div>
				<div>
					<div>
				<center><style>
* {
  box-sizing: border-box;
}
/* Create two unequal columns that floats next to each other */
.column {
  float: left;
  padding: 0px;
  height: auto; /* Should be removed. Only for demonstration */
}

.left {
  width: 100%;
}

.right {
  width: 0%;
}
h2.headertekst {
  text-align: center;
}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>
</center>
<body>
<div class="row">
  <div class="column left" style="background-color:#fff;">
 <body>
	<div class="col-md-1"></div>
	<div class="col-md-9 well">
	    <?php
echo "Date viewed:  " . date("l d/m/Y");
?>
		<hr style="border-top:1px dotted #2e1353;" />
		
<head>
<style>
      .img-container {
        text-align: center;
        display: block;
      }
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 2px solid #f7a823;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 2px solid #2e1353;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<body>
<h4>STUDENT DETAILS </h4>
<table style="width:100%">
  <tr>
    <td><b>&nbsp; REGISTRATION NUMBER:</b> <b style="color:#e63329;"><u><?php echo $Adm; ?>, </b> </td>
    <td><b>&nbsp; FULL NAME:</b> <b style="color:#e63329;"><u><?php echo $name; ?>, </b></td>
  </tr>
  <tr>
   <td><b>&nbsp; PROGRAMME OF STUDY:</b> <b style="color:#e63329;"><u><?php echo $course; ?>, </b> </td>
<td><b>&nbsp; COHORT:</b> <b style="color:#e63329;"><u><?php echo $studyyear; ?>, </b> </td> 
  </tr>
</table>
<br>
<h4>SELECT RESULTS TO PREVIEW </h4>
<table style="width:100%">
  <tr>
<td><h4><U>SCHOOL OF BUSINESS MANAGEMENT </U></h4><br>
    <select name="ap">
      <option>Please choose an option</option>
    </select>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script>
      const $select = $('select[name="ap"]');
      const opts = [
        {'value':'../bcom/bcom1a.php', 'text':'BCOM 1.2'},
        {'value':'../bcom/bcom31fn.php', 'text':'BCOM 3.1 FINANCE'},
        {'value':'../bcom/bcom31hr.php', 'text':'BCOM 3.1 HUMAN RESOURCE'},
        {'value':'../bcom/bcom41acc.php', 'text':'BCOM 4.1 ACCOUNTING'},
        {'value':'../bcom/bcom41fin.php', 'text':'BCOM 4.1 FINANCE'},
      ];
      opts.forEach(function(obj){
        $("<option />", {
          value: obj.value,
          text: obj.text
        }).appendTo($select)
      });

      $select.on("change", function(){
        window.location = this.value;
      });
    </script>
<td><h4><U>SCHOOL OF DEVELOPMENT AND STRATEGIC STUDIES </U></h4><br>
<head>
    <script language="javascript">
function SelectRedirect(){
// ON selection of section this function will work
//alert( document.getElementById('s1').value);

switch(document.getElementById('s1').value)
{
case "DIR":
window.location="../BAIR/dir.php";
break;

case "BAIR 1.2":
window.location="../BAIR/bair1b.php";
break;

case "BAIR 3.1":
window.location="../BAIR/bair3a.php";
break;

case "BAIR 4.1ds":
window.location="../BAIR/bair4ds.php";
break;
case "BAIR 4.1fpd":
window.location="../BAIR/bair4fpd.php";
break;

case "BAIR 4.1pss":
window.location="../BAIR/bair4pss.php";
break;

/// Can be extended to other different selections of SubCategory //////
default:
window.location="../"; // if no selection matches then redirected to home page
break;
}// end of switch 
}
////////////////// 
</script>
</head>
<body>

<SELECT id="s1" NAME="section" onChange="SelectRedirect();">
<Option value="">Please choose an option</option>
<Option value="DIR">DIPLOMA IN INTERNATIONAL RELATIONS</option>
<Option value="BAIR 1.2">BAIR 1.2</option>
<Option value="BAIR 3.1">BAIR 3.1</option>
<Option value="BAIR 4.1ds">BAIR 4.1 DEVELOPMENT STUDIES</option>
<Option value="BAIR 4.1fpd">BAIR 4.1 FOREIGH POLICY & DIPLOMACY</option>
<Option value="BAIR 4.1pss">BAIR 4.1 PEACE & SECURITY STUDIES</option>
</SELECT>
</td>
</body>
</table>
</br>
</table>
<br>

<table style="width:100%">
  <tr>
<td><h4><U>SCHOOL OF EDUCATION </U></h4><br>
<select id="dynamic_select">
<Option value="">Please choose an option</option>
<Option value="#">BEDA 1.2</option>
<Option value="#">BEDA 3.1</option>
<Option value="#">BEDA 4.1 DEVELOPMENT STUDIES</option>
<Option value="#">BEDA 4.1 FOREIGH POLICY & DIPLOMACY</option>
<Option value="#">BEDA 4.1 PEACE & SECURITY STUDIES</option>
</select>
<script>
$(function(){
// bind change event to select
$('#dynamic_select').on('change', function () {
var url = $(this).val(); // get selected value
if (url) { // require a URL
window.location = url; // redirect
}
return false;
});
});
</script>
    
<td><h4><U>SCHOOL OF INFORMATION COMMUNICATION TECHNOLOGY </U></h4><br>

<body>
<select onchange="location = this.value;">
    <Option value="">Please choose an option</option>
<Option value="#">BIT 1.2</option>
<Option value="#">BIT 3.1</option>
<Option value="#">BIT 4.1 DEVELOPMENT STUDIES</option>
<Option value="#">BIT 4.1 FOREIGH POLICY & DIPLOMACY</option>
<Option value="#">BIT 4.1 PEACE & SECURITY STUDIES</option>
</select>
</td>
</body>
</table>
</br>

<table style="width:100%">
  <tr>
<td><h4><U>SCHOOL OF AEROSPACE SCIENCE AND MARITIME STUDIES </U></h4><br>
<select onchange="location = this.value;">
    <Option value="">Please choose an option</option>
<Option value="../ASMS/dam.php">DIPLOMA IN AVIATION MANAGEMENT</option>
</select>
</td>

</body>
</table><BR>
<style>
.button1 {
  border: #f4a024;
  color: white;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
.button2 {
  border: #2e1353;
  color: #fff; !important;
  padding: 10px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
  .button3 {
  border: #2e1353;
  color: #fff; !important;
  padding: 10px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
.button1 {background-color: #2e1a47;} 
.button2 {background-color: #f7a823;}
.button3 {background-color: #2e1353;} 
</style>
<form>
<button style="float: right;"class="button button3"><a href="logout.php">LOG OUT</a></button>

</form>

</body>
 </script>
  </div>
 
<style>
.button1 {
  border: #f7a823;
  color: #f7a823;
  padding: 15px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
}
.button2 {
  border: #2e1353;
  color: white;
  padding: 13px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
}
.button2 {background-color: #e63329;}
.button1 {background-color: #2e1353;} 
</style>
</head>
<BR><BR>

		</div> 
	</div> 
	<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
    color:#000;
}
</style>
<header><BR>
		     <p style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</p> <BR>
		 </header>
		</div> 
</body>
</html>
	    	<?php
	    	exit();
	    } 
?>

<!DOCTYPE html> 
<html>
<head>
	<link rel="shortcut icon" href="
	https://piu.ac.ke/wp-content/uploads/2021/09/favicon.png" />
	<title>Pioneer International University</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" type="text/css" href="main.css" />
	<!-- include our jQuery file --> 
	<script src="jquery.js"></script> 
	<script src="chat.js"></script> 
</head>
<body>
	<div class="container content-holder">
		<div class="page-header">
		     <h3><a href="#">
         <img style="float:left; alt="Qries" src="https://piu.ac.ke/wp-content/uploads/2021/09/PIU-LOGO-WHITE.png"
         width=270" height=110"></a>
        <div style="text-align:center"><h1> EXAM OFFICE</h1> <br> <h3 style="color:#fff;">SEMESTER RESULTS</h3> </div>
		</div>

		<div class="content">
		    <div class="row">
			    <div class="col-md-1"> 
			    	<center></center>

			    </div> 
			    <div class="col-md-10 form-login">
			    	<?php require_once "accounts.inc.php"; ?> 
			    </div> 
			    <div class="col-md-1"></div> 
		    </div><!-- closing div class row --> 
		    <br>
		    <br>
		   <div>
		<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
}
</style>
<header style="color:#2e1353;">
		     <p style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</p> 
		 </header>
		</div>
		</div> 
	</div>  
</body>
</html>
