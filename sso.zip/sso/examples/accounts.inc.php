<?php 
   if(!isset($_GET['register'])){
   	?> 
   	   
   	   <?php
   	        
   	        if(isset($_POST['username']) && isset($_POST['password'])){
   	        	$username = $_POST['username']; 
   	        	$password = $_POST['password'];
   	        	login($username, $password);
   	        }
   	    ?> 
<br>

   	   <form class="form-horizontal" method="post" actio="">
   	   	   <div class="form-group">
   	   	   	    <label for="username" class="col-md-4"><br>UNIVERSITY EMAIL ADDRESS:</label>
   	   	   	    <div class="col-md-6"> 
   	   	   	    	<input type="text"  autocomplete="off" id="username" name="username" class="form-control">
   	   	   	    </div> 
   	   	   	    <div class="col-md-4"></div> 
   	   	   </div> 
   	   	   <div class="form-group">
   	   	   	    <label for="password" class="col-md-4"><br>ADMISSION NUMBER: <br><b style="color:#ee3342;">ie,(BEDA/000/2000)</b></label>
   	   	   	    <div class="col-md-6"> 
   	   	   	    	<input type="password" id="password" name="password" class="form-control">
   	   	   	    </div> 
   	   	   </div> 

   	   	   <div class="form-group">
   	   	   	    <div class="col-md-1"></div>
   	   	   	    <div class="col-md-8" style="text-align:center"> 
   	   	   	    	<input class="btn btn-primary" type="submit" name="submit" value="&nbsp;&nbsp;&nbsp;&nbsp; LOGIN&nbsp;&nbsp;&nbsp;&nbsp;">
   	   	   	    </div> 
   	   	   </div> 
   	   	   <br>
<h4><b style="color:#ee3342;">NOTE :</b> <b style="color:#2e1353;">Your admission number should be in CAPS. ie, (BEDA/0000/2000)</h4>
<br>

<h4><b style="color:#f39324">For assistance call:<a href="tel:+254 740 635 660" style="color:#00008B;"><b> <u style="color:#2e1353">0740 635 660</a></u> </b> or <a href="tel:+254  740 635 663" style="color:#00008B;"><b> <u style="color:#2e1353"> 0740 635 663</a></u> </b></h4>
<br>
<h4 style="color:#f7a823;"><B>Email:</B><a href="mailto:exam.office@piu.ac.ke" style="color:#00008B;"><b> <u>exam.office@piu.ac.ke</a></u> </b></h4>


   	   	   <div class="form-group">
   	   	   	    <div class="col-md-2"></div>
   	   	   	    <div class="col-md-8"> 
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 
   	   </form> 
   	<?php
   } else {
   	 if($_GET['register'] == ""){
   	 	header("location:index.php");
   	  }
   	?> 
   	<form class="form-horizontal" method="post" actio="">
   	   	   <div class="form-group">
   	   	   	    <label for="user" class="col-md-2">Username</label>
   	   	   	    <div class="col-md-8"> 
   	   	   	    	<input type="text" value="<?php echo $username; ?> " autocomplete="off" id="user" name="user" class="form-control">
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 

   	   	   <div class="form-group">
   	   	   	    <label for="name" class="col-md-2">Name</label>
   	   	   	    <div class="col-md-8"> 
   	   	   	    	<input id="name" value="<?php echo $name; ?>" type="text" id="name" name="name" class="form-control">
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 

   	   	   <div class="form-group">
   	   	   	    <label for="pas" class="col-md-2">password</label>
   	   	   	    <div class="col-md-8"> 
   	   	   	    	<input type="password" id="pas" name="pas" class="form-control">
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div>

   	   	   <div class="form-group">
   	   	   	    <label for="gender" class="col-md-2">Gender</label>
   	   	   	    <div class="col-md-8"> 
   	   	   	        <select name="gender" id="gender">
   	   	   	        	<option value="">--Please select your gender--</option> 
   	   	   	        	<option value="Male">Male</option> 
   	   	   	        	<option value="Female">Female</option> 
   	   	   	        </select> 
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 

   	   	   <div class="form-group">
   	   	   	    <div class="col-md-2"></div>
   	   	   	    <div class="col-md-8"> 
   	   	   	    	<input class="btn btn-primary" type="submit" name="regisgter" value="Register">
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 

   	   	   <div class="form-group">
   	   	   	    <div class="col-md-2"></div>
   	   	   	    <div class="col-md-8"> 
   	   	   	    	<a href="index.php?register=">Login here</a>
   	   	   	    </div> 
   	   	   	    <div class="col-md-2"></div> 
   	   	   </div> 
   	   </form> 
   	<?php 
   }
?>