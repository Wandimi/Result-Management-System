<?php
	$conn = new mysqli("mysql:host=localhost;dbname=piuac_test;charset=utf8","piuac_test","piuac_test");
	
	if(!$conn){
		die("Error: Can't connect to database");
	}
?>