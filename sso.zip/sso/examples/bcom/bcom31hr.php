<?php 
	    require_once "../functions.php";
	    {
	    	   $salt = $_SESSION['uname']; 
	    	   $name = coffee($salt, 'name'); 
	    	   $gender = coffee($salt, 'username');
	    	   $profile1 = coffee($salt,'profile');
	    	   $course = coffee($salt,'course');
	    	   $semester = coffee($salt,'semester');
	    	   $Adm = coffee($salt,'Adm');
	    	   $phone_no = coffee($salt,'phone_no');
	    	   $email = coffee($salt,'email');
	    	   $school = coffee($salt,'school');
	    	   $studyyear = coffee($salt,'studyyear');
	    	   $coursecode1 = coffee($salt,'coursecode1');
	    	   $unit1 = coffee($salt,'unit1');
	    	   $grade1 = coffee($salt,'grade1');
	    	   $status1 = coffee($salt,'status1');
	    	   $coursecode2 = coffee($salt,'coursecode2');
	    	   $unit2 = coffee($salt,'unit2');
	    	   $grade2 = coffee($salt,'grade2');
	    	   $status2 = coffee($salt,'status2');
	    	   $coursecode3 = coffee($salt,'coursecode3');
	    	   $unit3 = coffee($salt,'unit3');
	    	   $grade3 = coffee($salt,'grade3');
	    	   $status3 = coffee($salt,'status3');
	    	   $coursecode4 = coffee($salt,'coursecode4');
	    	   $unit4 = coffee($salt,'unit4');
	    	   $grade4 = coffee($salt,'grade4');
	    	   $status4 = coffee($salt,'status4');
	    	   $coursecode5 = coffee($salt,'coursecode5');
	    	   $unit5 = coffee($salt,'unit5');
	    	   $grade5 = coffee($salt,'grade5');
	    	   $status5 = coffee($salt,'status5');
               $coursecode6 = coffee($salt,'coursecode6');
	    	   $unit6 = coffee($salt,'unit6');
	    	   $grade6 = coffee($salt,'grade6');
	    	   $status6 = coffee($salt,'status6');
	    	   $coursecode7 = coffee($salt,'coursecode7');
	    	   $unit7 = coffee($salt,'unit7');
	    	   $grade7 = coffee($salt,'grade7');
	    	   $status7 = coffee($salt,'status7');
	    	   $totalunits = coffee($salt,'totalunits');
	    	   $recomendations = coffee($salt,'recomendations');
	    	?> 
<!DOCTYPE html> 
<html>
<head>
    <style type="text/css" media="print">
@page {
    size: auto;   /* auto is the initial value */
    margin: 0;  /* this affects the margin in the printer settings */
}
</style>
<link rel="shortcut icon" href="https://piu.ac.ke/wp-content/uploads/2021/09/favicon.png" />
	<title>Pioneer International University</title>
	<meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="../bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../main.css" />
	<link rel="stylesheet" type="text/css" href="../style.css" />
	<!-- include our jQuery file --> 
	<script src="jquery.js"></script> 
	
	<script src="chat.js"></script> 
	<script>
	    //custom scroll bars for some dive elements this
	    // script is optional 
		
	</script> 
</head>
<body style="position: relative;">
	<div class="overlay"></div> 
	<div class="overlay-data">
		<h2>Please Wait ....</h2>
	</div> 

	<div class="container content-holder">
		<div class="page-header">
			<div class="pull-left" style="margin-left: 50px;"></div> 
		</div>
		<div class='net' style="background: #2e1353; padding: 10px; color: white; text-align: center; font-size: 18px; display: none;">
		      We are having trouble connecting to the server. Please wait while we reconnect you 
		      <div class="pull-right"><img src="small-loading.gif" /></div> 
		</div> 
		<div class="page-header show-simples" style="opacity:0.8; display: none; font-size: 20px; padding: 10px; text-align: center; background:url(ic_next.png) left center no-repeat green; color: white;">
			     <span>Nothing to show right now</span>
		</div> 

			<!-- end of the chat toolBar -->

			<div class="row">
				<br>
				</div>
				<div>
					<div>
				<center><style>
* {
  box-sizing: border-box;
}
/* Create two unequal columns that floats next to each other */
.column {
  float: left;
  padding: 0px;
  height: auto; /* Should be removed. Only for demonstration */
}

.left {
  width: 0%;
}

.right {
  width: 100%;
}
h2.headertekst {
  text-align: center;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>
</center>
<body>
  <div class="column right" style="background-color:#fff;">
  <body>
<style>
.button1 {
  border: #f4a024;
  color: white;
  padding: 10px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
.button2 {
  border: #2e1353;
  color: #fff; !important;
  padding: 10px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
 .button3 {
  border: #2e1353;
  color: #fff; !important;
  padding: 10px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 20px;
}
 .h5left {
  border: #2e1353;
  color:#2e1353; !important;
  padding: 10px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: -10px 2px;
  font-weight: bold;
  border-radius: 20px;
}
.button1 {background-color: #2e1a47;} 
.button2 {background-color: #f7a823;}
.button3 {background-color: #e20000;} 
</style>
</head>
<body>
	<div class="col-md-1"></div>
	<div class="col-md-9 well">
<?php
// set the default timezone to use.
date_default_timezone_set('Africa/Nairobi');
// Prints something like: Monday 8th of August 2005 03:12:46 PM
echo date('l jS \of F Y h:i:s A');
?>

<b><h5 style="float: right;"class="h5left">EXAMINATION OFFICE</h5></b>

		<hr style="border-top:1px dotted #2e1353;" />
		
<head>
<span class="img-container"> <!-- Inline parent element -->
      <img src="https://e-learning.piu.ac.ke/wp-content/uploads/2020/05/PIU-LOGO-1-1-1.png" style="width:250px;height:90px;">
    </span>
<style>
      .img-container {
        text-align: center;
        display: block;
      }
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 2px solid #f7a823;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 2px solid #2e1353;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
    <style>
.watermark {
    position: absolute;
    color: #2e1353;
    opacity: 15%;
    font-size: 20px;
    width: 100%;
    top: 1%; 
    letter-spacing: 3px;
    line-height: 2.8;
    transform: rotate(0deg);
    text-align: top;
    z-index: 0;
}
</style><br>
<table style="width:100%">
    <div class="watermark">Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University Pioneer International University   </div>
  <tr>
    <td>STUDENT NAME: <b> <?php echo $name; ?></b> </td>
    <td>SCHOOL NAME: <b><?php echo $school; ?></b> </td>
  </tr>
  <tr>
   <td>ADMISSION NUMBER: <b><?php echo $Adm; ?></b> </td>
<td>COHORT: <b><?php echo $studyyear; ?></b> </td> 
  </tr>
  <tr>
   <td>PROGRAMME OF STUDY: <b><?php echo $course; ?></b></td>
    <td>SEMESTER:  <b><?php echo $semester; ?></b> </td>
  </tr>
</table>
<br>
<table>
  <tr>
      <th>S/NO</th>
    <th>UNIT CODE</th>
    <th>UNIT NAME</th>
    <th>GRADE</th>
    <th>STATUS</th>
  </tr>
  <tr>
      <td ><b>1</b></td>
    <td ><b><?php echo $coursecode1; ?></b></td>
    <td ><b><?php echo $unit1; ?></b></td>
    <td ><b><?php echo $grade1; ?></b></td>
    <td ><b><?php echo $status1; ?></b></td>
    </tr>
    <tr>
        <td ><b>2</b></td>
    <td ><b><?php echo $coursecode2; ?></b></td>
    <td ><b><?php echo $unit2; ?></b></td>
    <td ><b><?php echo $grade2; ?></b></td>
    <td ><b><?php echo $status2; ?></b></td>
    </tr>
    <tr>
        <td ><b>3</b></td>
    <td ><b><?php echo $coursecode3; ?></b></td>
    <td ><b><?php echo $unit3; ?></b></td>
    <td ><b><?php echo $grade3; ?></b></td>
    <td ><b><?php echo $status3; ?></b></td>
    </tr>
        <tr>
            <td ><b>4</b></td>
    <td ><b><?php echo $coursecode4; ?></b></td>
    <td ><b><?php echo $unit4; ?></b></td>
    <td ><b><?php echo $grade4; ?></b></td>
    <td ><b><?php echo $status4; ?></b></td>
    </tr>
        <tr>
            <td ><b>5</b></td>
    <td ><b><?php echo $coursecode5; ?></b></td>
    <td ><b><?php echo $unit5; ?></b></td>
    <td ><b><?php echo $grade5; ?></b></td>
    <td ><b><?php echo $status5; ?></b></td>
    </tr>
        <tr>
            <td ><b>6</b></td>
   <td ><b><?php echo $coursecode6; ?></b></td>
    <td ><b><?php echo $unit6; ?></b></td>
    <td ><b><?php echo $grade6; ?></b></td>
    <td ><b><?php echo $status6; ?></b></td>
    </tr>
        <tr>
            <td ><b>7</b></td>
    <td ><b><?php echo $coursecode7; ?></b></td>
    <td ><b><?php echo $unit7; ?></b></td>
    <td ><b><?php echo $grade7; ?></b></td>
    <td ><b><?php echo $status7; ?></b></td>
    </tr>
    <tr>
            <th colspan="2"><b>TOTAL UNITS:&nbsp;&nbsp;<?php echo $totalunits; ?> </b></th>
    <th style="text-align:center;" colspan="3"><b >RECOMENDATION:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $recomendations; ?></b></td>
    </th>
</table>

<p style="text-align:center"><b style="color:#e20000"><i>NOTE: This is a system generated report. This is not an official university document.</p></b></i>

<form>
<left><button id="PrintButton" onclick="PrintPage()"class="button button1">PRINT THIS PAGE</button></left>
<button style="position: relative; left: 30%;" class="button button2"><a href="../server/index.php">HOME PAGE</a></button>
<button style="float: right;"class="button button3"><a href="../logout.php">LOG OUT</a></button>

</form>
</body>

<script type="text/javascript">
	function PrintPage() {
		window.print();
	}
	
</script>

		</div> 
	</div>

  
	<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
}
</style>
<header>
		     <p style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</p> 
		 </header>
		</div> 
</body>
</html>
	    	<?php
	    	exit();
	    } 
?>

<!DOCTYPE html> 
<html>
<head>
	<link rel="shortcut icon" href="
	https://piu.ac.ke/wp-content/uploads/2021/09/favicon.png" />
	<title>Pioneer International University</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../main.css" />
	<!-- include our jQuery file --> 
	<script src="../jquery.js"></script> 
	<script src="../chat.js"></script> 
</head>
<body>
	<div class="container content-holder">
		<div class="page-header">
		     <h3><a href="#">
         <img alt="Qries" src="https://piu.ac.ke/wp-content/uploads/2021/09/PIU-LOGO-WHITE.png"
         width=200" height=80"> </a>STUDENT RESULT VERIFICATION SYSTEM</h3> 
		</div>

		<div class="content">
		    <div class="row">
			    <div class="col-md-1"> 
			    	<center></center>

			    </div> 
			    <div class="col-md-10 form-login">
			    	<?php require_once "../accounts.inc.php"; ?> 
			    </div> 
			    <div class="col-md-1"></div> 
		    </div><!-- closing div class row --> 
		    <br>
		    <br>
		   <div>
		<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
}
</style>
<header style="color:#2e1353;">
		     <p style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</p> 
		 </header>
		</div>
		</div> 
	</div>  
</body>
</html>