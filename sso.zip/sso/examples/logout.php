<?php
//LOGOUT.PHP
session_start(); 
//// destroy all $_SESSION variables
session_destroy();
echo "<script>window.open('https://www.office.com/estslogout','_self')</script>";
?>
