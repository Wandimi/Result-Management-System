<?php 
	    require_once "functions.php";

	    if(confirmLogin()){
	    	   $salt = $_SESSION['id']; 

	    	   $name = ucwords(user($salt, 'name'));
	    	   $username = ucwords(user($salt, 'username')); 
	    	   $gender = user($salt, 'username');
	    	   $profile1 = user($salt,'profile');
	    	   $course = user($salt,'course');
	    	   $Adm = user($salt,'Adm');

	    	    if($profile1 == "" && $gender =="Male"){
    				$profilImage1 = "male.jpg";
    			} else if($profile1 == "" && $gender =="Female") {
    				$profilImage1 = "female.jpg";
    			} else {
    				$profilImage1 = $profile1; 
    			}
	    	?> 
<!DOCTYPE html> 
<html>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
<head>
<link rel="shortcut icon" href="https://piu.ac.ke/wp-content/uploads/2021/09/PIU-LOGO-WHITE.png" />
	<title>Pioneer International University</title>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" type="text/css" href="main.css" />
	<link rel="stylesheet" type="text/css" href="style.css" />
	<!-- include our jQuery file --> 
	<script src="jquery.js"></script> 
	
	<script src="chat.js"></script> 
	<script>
	    //custom scroll bars for some dive elements this
	    // script is optional 
		
	</script> 
</head>
<body style="position: relative;">
	<div class="overlay"></div> 
	<div class="container content-holder">
		<div class="page-header">
			<div class="pull-left" style="margin-left: 50px;"></div> 
		</div>
		<div class='net' style="background: #2e1353; padding: 80px; color: white; text-align: center; font-size: 18px; display: none;">
		      We are having trouble connecting to the server. Please wait while we reconnect you 
		      <div class="pull-right"><img src="small-loading.gif" /></div> 
		</div> 
		
			<!-- end of the chat toolBar -->

			<div class="row">
				<br>
				</div>
				<div>
					<div>
				<center><style>
* {
  box-sizing: border-box;
}
/* Create two unequal columns that floats next to each other */
.column {
  float: left;
  padding: 25px;
  height: auto; /* Should be removed. Only for demonstration */
}

.left {
  width: 0%;
}

.right {
  width: 100%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
h3.headertekst {
  text-align: center;
}
</style>
</center>
<body>

<div class="row">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
  </div>
  <div class="column right"; style="background-color:#fff;">
    <style>
img {
  float: left;
}
</style>
    <p><img alt="Qries" src="images/PIU LOGO.png"
         width=250" height=90" ALIGN=”left”>
<p style="color:#000;"align="right">Pioneer International University,
<br>Murang’a Road, Opposite KICD. 
<br> P.O Box 33421-00600, Nairobi Kenya.
<br>Tel. 0740 635 660/1/2, 0700 372 352/4/5 
<br>Email: admissions@piu.ac.ke
 <br>Website: www.piu.ac.ke.     
  <br> </p>      
<u><p style="color:#f7a823;"align="right">Friday, August 20, 2021.</p></b></u>
    
    
    <h4><b>DEAR:</b></td><td> <b style="color:#2e1353;"><u><?php echo $name; ?>, </b></u><br></h4>
    <h5><b>REF: </b> <b style="color:#f7a823;"><u>UNIVERSITY ADMISSION AS A GOK SPONSORED STUDENT THROUGH KUCCPS</b></u></h5></td><br>
    <P>Receive warm Greetings and best wishes from Pioneer International University (PIU)!</P>
    
    
 <P>Following your success in the 2020 KCSE Examinations, I am pleased to inform you that through Kenya Universities and Colleges Central Placement Service (KUCCPS) you have been admitted as a Government of Kenya (GOK) sponsored student for the <b style="color:#2e1353;"><u><?php echo $course; ?></u></b> degree. Your student Admission number is <b style="color:#2e1353;"><u><?php echo $Adm; ?></b></u>. <BR>
 <P>You are requested to report to the University on<B> Monday 13th September 2021.</B> at <B>8.00am.</B> Classes commence on <B>Monday 20th September 2021.</B></P></P>
<h5><b style="color:#f7a823;">Please note that you are required to submit the following documents for admission: -</b></h5></td>
<p>
    <ol>
<li>ORIGINAL copy of the Pioneer International University Admission letter.</li>
<li>ORIGINAL and 2 copies of KCSE Certificate or Result Slip.</li>
<li>ORIGINAL and 2 copies of National Identity Card /Passport /Birth Certificate.</li>
<li>4 recent passport size photographs.</li>
<li>An active NHIF Membership card.</li>
<li>Duly filled and signed Pioneer International University Students Forms:</li>
<ul>
<li>Student Declaration</li>
<li>Student Entrance Medical Examination (To be filled by a Medical Officer from a Registered County Hospital)</li>
<li>Academic Declaration Form</li>
<li>Declaration of acceptance to pay fees</li>
</ul>
</ol>
</p>  

<h5><b style="color:#f7a823;">Further, note the following:</b></h5></td>
<ol>
<li>The University has limited accommodation to be allocated only on a first come first basis; however, there are private hostels available outside the University.</li>
<li>As a GOK sponsored student you are eligible for the University Education Loan and are encouraged to apply to the Higher Education Loans Board (HELB) through <B><a href="https://www.helb.co.ke" target="_blank">https://www.helb.co.ke</a></B>. Application for this student loan is currently ongoing.</li>
</ol>
    
<p>On behalf of the Pioneer International University, I take this early opportunity to congratulate you as you join the PIU Family in pursuit of your dream career.</p>
<br>

<p>Sincerely</p>
<p>David M Ngamate</p>
<p>Registrar</p>
<p>Encl.</p>
<p><img alt="Qries" src="images/regsign.png"
         width=200" height=130" ALIGN=”left”></p>

<div id="editor"></div>
<center>
  <p>
 <div class="text-center">
        <button1 onclick="window.print();" class="button button1" id="print-btn">PRINT ADMISSION LETTER</button>
      </div>
  </p>

</center>
<script type="text/javascript">

$homepage = file_get_contents('https://piu.ac.ke/kuccps-2021/admission.php');
echo $https://piu.ac.ke/kuccps-2021/main.php;

var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#generatePDF').click(function () {
    doc.fromHTML($('#htmlContent').html(), 15, 15, {
        'width': 700,
        'elementHandlers': specialElementHandlers
    });
    doc.save('sample_file.pdf');
});
</script>

</head>
<br>
  </div>
</div>
</div>
<div>
    <style>
.button1 {
  border: #f4a024;
  color: white;
  padding: 15px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
}
.button2 {
  border: #2e1353;
  color: white;
  padding: 13px 10px;
  text-align: left !important;
  text-decoration: none;
  display: inline-block;
  font-size: 13px;
  margin: 4px 2px;
  cursor: pointer;
}
.button2 {background-color: #e63329;}
.button1 {background-color: #2e1a47;} 
</style><BR><BR><button>
&nbsp;<B> &nbsp;</B> <a href="https://piu.ac.ke/kuccps-2021/main.php" class="button button1"> BACK TO INSTRUCTIONS PAGE</button></a> <BR>
      <BR><BR>
		</div> 

	</div> 
	<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
}
</style>
<header>
		     <h4 style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</h4> 
		 </header>
		</div> 
</body>
</html>
	    	<?php
	    	exit();
	    } 
?>

<!DOCTYPE html> 
<html>
<head>
	<link rel="shortcut icon" href="https://e-learning.piu.ac.ke/wp-content/uploads/2020/05/cropped-PIU-ICON-512x512-2-1-192x192.png" />
	<title>PIU KUCCPS PLACEMENT</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" type="text/css" href="main.css" />
	<!-- include our jQuery file --> 
	<script src="jquery.js"></script> 
	<script src="chat.js"></script> 
</head>
<body>
	<div class="container content-holder">
		<div class="page-header">
		     <h3><a href="#">
         <img alt="Qries" src="https://www.piu.ac.ke/wp-content/uploads/2019/06/PIU-LOGO-WHITE.png"
         width=140" height=50"> </a>KUCCPS (Kenya Universities and Colleges Central Placement Service)</h3> 
		</div>

		<div class="content">
		    <div class="row">
			    <div class="col-md-6"> 
			    	<center><h3 style="color:#f4a024;"><marquee>Powered By Intellect, Driven By Values</marquee></h3></center>

			    	 <img src="alive-chat.png"  class="img-responsive pull-right" alt="chat-home" />
			    </div> 
			    <div class="col-md-5 form-login">
			    	<?php require_once "accounts.inc.php"; ?> 
			    </div> 
			    <div class="col-md-1"></div> 
		    </div><!-- closing div class row --> 
		    <br>
		    <br>
		   <div>
		<div class="page-footer">
			<style>
header
{
    background-color:#f4a024;
}
</style>
<header>
		     <h4 style="text-align:center">Copyright © 2021 Pioneer International University. All Rights Reserved.</h4> 
		 </header>
		</div>
		</div> 
	</div>  
</body>
</html>