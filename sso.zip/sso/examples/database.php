<?php
$servername='localhost';
$username='piuac_test';
$password='piuac_test';
$dbname = "piuac_test";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>