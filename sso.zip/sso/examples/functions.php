<?php 

    // connect to the database ;
    ob_start(); 
    session_start();
	
    function connect(){
    	try{
    		$db = new PDO("mysql:host=localhost;dbname=piuac_test;charset=utf8","piuac_test","piuac_test");
    		//echo "connected";
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    	}catch(PDOException $e){
    		die($e->getMessage()); 
    	}
    	return $db; 
    }
    function login($username, $password){
    	if(empty($username) || empty($password)){
    		echo "<div class='errors'>Incorrect Credentials</div>";
    		return; 
    	}
    	$user = preg_replace('/\s+/', '', htmlentities($username));
    	$pas = preg_replace('/\s+/', '', htmlentities($password));
    	$db = connect(); // this one is returning the pdo object; 
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    	try{
            $query = $db->prepare("SELECT id, username, password FROM users WHERE username=? AND password=? ");
            $query->bindParam(1,$user);
            $query->bindParam(2, $pas);
            $query->execute();
        } catch(PDOException $e){
            die($e->getMessage()); 
        }

    	$foundData = $query->fetch(PDO::FETCH_NUM);
    	$dataId = $foundData[0]; 
    	$dataUsername = $foundData[1];
    	$dataPassword = $foundData[2];
        echo $query->rowCount(); 

    	if($user != $dataUsername &&  $pas != $dataPassword){
    		echo "<div class='errors'>Incorrect Credentials</div> "; 
    	}  else {
    		$salt = $dataId;
    		$queryCheckSalt = $db->prepare("SELECT * FROM users WHERE (username=:username AND password=:password ) AND salt=:salt ");
    		$queryCheckSalt->bindParam(':username',$user);
    		$queryCheckSalt->bindParam(':password',$pas);
    		$queryCheckSalt->bindparam(':salt',$salt); 
    		$queryCheckSalt->execute(); 
    		$found = $queryCheckSalt->rowCount();
    		if($found == 0){
    			$queryUpdateSalt = $db->prepare("UPDATE users SET salt=:salt WHERE username=:username and password=:password"); 
    			$queryUpdateSalt->bindParam(':username', $user);
    			$queryUpdateSalt->bindParam(':password', $pas);
    			$queryUpdateSalt->bindParam(':salt', $salt);
    			$queryUpdateSalt->execute();
    		}
    		$_SESSION['id'] = $salt;
    		header("Location:index.php");

    	}
    }
    function user($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM users WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function gachamba($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom1a WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    
function bcom1a($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom1a WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
  function sugar($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom31fn WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    } 
    function bcom31fn($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom31fn WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function coffee($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom31hr WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    } 
    function bcom31hr($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom31hr WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function tea($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom41fin WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function bcom41fin($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom41fin WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
        function cocoa($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom41acc WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function bcom41acc($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bcom41acc WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
function maize($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair1b WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }        
     function bair1b($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair1b WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
            function bair3a($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair3a WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
        }
        function pea($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair3a WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
        }
            function bair4ds($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4ds WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
        }
        function cowpea($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4ds WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
        }
            function bair4fpd($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4fpd WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function millet($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4fpd WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
     function bair4pss($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4pss WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function rice($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bair4pss WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
     function diploma_IR($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM diploma_IR WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function sorghum($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM diploma_IR WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
         function dam($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM dam WHERE salt=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function bean($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM dam WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
        function zebu($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM beda12 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function cattle($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM beda22 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
        function mouse($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM sitd12 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
            function keyboard($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM sitd21 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function ram($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bsit12 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function screen($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bsit31 WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function cmos($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bsit4na WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
        function cpu($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bsit4se WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function cam($id, $field){
    	$db = connect();
        
        try{
            $query = $db->prepare("SELECT $field FROM bsit4sc WHERE username=? ");
            $query->bindParam(1, $id); 
            $query->execute();
        } catch(PDOException $e){
            die("Eror due to <strong>".$e->getMessage()."</strong>");
        }
    	 
    	$returnedRow = $query->fetch(PDO::FETCH_NUM); 

    	return $returnedRow[0];
    }
    function confirmLogin(){
    	if(isset($_SESSION['id']) && $_SESSION['id'] != ""){
    		return true; 
    	} else {
    		return false; 
    	}

    }

?> 